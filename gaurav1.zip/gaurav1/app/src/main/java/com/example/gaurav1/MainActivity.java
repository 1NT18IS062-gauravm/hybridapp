package com.example.gaurav1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    boolean isNewOp = true;
    EditText ed1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);
    }

    public void numberevent(View view){
        if(isNewOp)
            ed1.setText("");
        isNewOp=false;
        String number = ed1.getText().toString();
        switch(view.getId()){
            case R.id.one:
                number += "1";
                break;
            case R.id.two:
                number += "2";
                break;
            case R.id.three:
                number += "3";
                break;
            case R.id.four:
                number += "4";
                break;
            case R.id.five:
                number += "5";
                break;
            case R.id.six:
                number += "6";
                break;
            case R.id.seven:
                number += "7";
                break;
            case R.id.eight:
                number += "8";
                break;
            case R.id.nine:
                number += "9";
                break;
            case R.id.zero:
                number += "0";
                break;
            case R.id.dot:
                number += ".";
                break;
            case R.id.plusminus:
                number = "-"+number;
                break;
        }
        ed1.setText(number);
    }
}